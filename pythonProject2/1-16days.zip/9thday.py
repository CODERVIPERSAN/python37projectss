#dictionary in python

#key value pair --of the dictionary
# x={"key1":"value1"
# ,"key2":"value2"}
# print(x)

#fetching
# print(x["key1"])

#adding new items
# x["key3"]="key3"
# print(x)

#empty dictionary {}

#void the exiting dicitonary

# x={}  emptying the existing dictionary voiding
# print(x)
###################################################################################3
#for loop  gives all the keys 
########################################################################################

#interactive coding exercise###########################################

# student_score={*
# 	"harry":81,
# 	"ron":78,
# 	"hermione ":99,
# 	"draco":74,
# 	"neville":62,
# 	"sandy":75
# }



# #creating one emty dictionary
# student_grade={}
# for name,score in student_score.items():
# 	if  90<score <=100:
# 		student_grade[name]='A'
# 	elif 80<score<=90:
# 		student_grade[name]='B'
# 	elif 70<score<=80:
# 		student_grade[name]='c'
# 	elif 60<score<=70:
# 		student_grade[name]='d'

# print(student_grade)


##########################################################
# nesting dictionary

# travel={
# 	"france":{"cities_visted":["paris","little","dijon"],"toatal_visits":10},
# 	"india":["coimbatore","trichy"]
# }

# list inside multiple dictionary
# travel=[
# 	{
# 		"country":"france" ,"cities_visited":["paris","little","dijon"]
# 		,"visits":6
# 		},
# 	{
# 		"country":"india","cities_visited":["coimbatore","trichy"]	,"visits":9
# 		}
# 	]
####################################################################

# def function(country,visits,cities_visited):
# 	new_dict={}
# 	key=travel[0]
# 	print(key)
# 	for x,y in key.items():
# 		if x=="country":
# 			new_dict[x]=country
# 		elif x=="cities_visited":
# 			new_dict[x]=cities_visited
# 		else:
# 			new_dict[x]=visits
# 	return travel.append(new_dict)
# function("russia",cities_visited=["moscow","saint"],visits=2)
# print(travel)
###################################################################
# start={
# 	"a":9,
# 	'b':8}
# start['c']=7
# final=start
# print(final)
####################################################################
#blind aution program 
################################################################
# from os import system
# run=True
# data={}
# while run: 
# 	system("clear")
# 	name=input("name of the bitter who is bitting ")
# 	bit_amount=int(input("enter the bitting amount "))
# 	condition=input("is the other person remaining in the bit")
# 	data[name]=bit_amount
	
# 	if condition=='yes':
# 		run=True
# 	elif condition=="no":
# 		run=False
# 	else:
# 		print("invalid ")
# 		run=False
# def winner(data):
# 	new_dict={}
# 	for name,bit_amount in data.items():
# 		new_dict[bit_amount]=name
# 	maxi=max(new_dict.keys())
# 	return new_dict[maxi],maxi

# print(f"hurray {winner(data)[0]} is the winner and he bit the amount of {winner(data)[1]}    end of the aution")

#################################################################

