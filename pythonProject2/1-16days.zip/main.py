from os import system
from time import sleep
from logo55 import logo

print(logo)
print("loading please wait")
sleep(10)
print("▓										 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓                                		 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓										 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓									 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓						 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█						 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██						 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓					 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓					 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓▓			 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓▓▓			 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓▓▓▓▓▓		 |")
sleep(1)
system('clear')
print(logo)
print("loading please wait")
print("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓|")
sleep(3)

#blackjack programming by me
import random

endloop = False
while (endloop == False):
    system('clear')
    print("♠♠♠♠♠♠ ♣♣♣♣ ♥♥♥♥♥♥♥♥ ♦♦♦♦♦♦♦♦♦♦")
    cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]

    def ace(lis):
        for element in range(len(lis)):
            if cards[0] == lis[element]:
                lis[element] = 1
                break

    def intial_deal():
        anymem = []
        for card in range(0, 2):
            anymem += [random.choice(cards)]
        return anymem

    player_cards = intial_deal()
    print(f"player cards-----{player_cards}-----{sum(player_cards)}")
    computer_cards = intial_deal()
    print(f"computer cards  {computer_cards[0]}")
    print("one card hided")

    #hit stand
    if not ((cards[12] in player_cards) and (cards[0] in player_cards)):
        deasion = (input("hit or stand")).strip()

        def computer(computer_cards, player_cards):
            if not ((cards[0] in computer_cards) and
                    (cards[12] in computer_cards)):
                if (sum(computer_cards) >
                        sum(player_cards)) and (sum(computer_cards) < 22):
                    print(
                        f"computer cards----{computer_cards}----{sum(computer_cards)}"
                    )
                    return "computer wins"
                while sum(computer_cards) < 17:
                    computer_cards += [random.choice(cards)]
                    print(
                        f"computer cards-----{computer_cards},--------{sum(computer_cards)}"
                    )
                    if sum(computer_cards) > sum(player_cards) and sum(
                            computer_cards) < 22:
                        return "computer wins"
                    if sum(computer_cards) > 21:
                        ace(computer_cards)
                    elif sum(computer_cards) > 21:
                        print(
                            f"computer cards-----{computer_cards}------{sum(computer_cards)}"
                        )
                        return "bust computer   ------  player wins "
                else:
                    while sum(computer_cards) < 17:
                        computer_cards += [random.choice(cards)]
                        print(
                            f"computer cards------{computer_cards}------{sum(computer_cards)}"
                        )
                        if sum(computer_cards) > 21:	
                            ace(computer_cards)
                        elif sum(computer_cards) > 21:
                            print(
                                f"computer cards ------{computer_cards}------{sum(computer_cards)}"
                            )
						
						
                    return comparison(computer_cards, player_cards)
            else:
                if (sum(computer_cards) == sum(player_cards)):
                    return f"sum of {computer_cards} is equal to {player_cards}which is {sum(computer_cards)} so...  \npush\n"
                else:
                    return f"{computer_cards},black jack computer wins "

        def comparison(computer_cards, player_cards):
            if sum(computer_cards) > sum(player_cards) and (sum(computer_cards) < 22):
                print(
                    f"computer cards------{computer_cards}-----{sum(computer_cards)}"
                )
                return f"computer cards------{computer_cards}-----{sum(computer_cards)}  \ncomputer wins\n "
            elif sum(computer_cards) == sum(player_cards):
                return "push"
            else:
                return f"player cards-----{player_cards}----{sum(player_cards)}  ,  player wins "

        print(sum(player_cards))
        while deasion == "hit":
            player_cards += [random.choice(cards)]
            print(f"player cards-----{player_cards}----{sum(player_cards)}")
            if sum(player_cards) > 21 and cards[0] in player_cards:
                ace(player_cards)
                print("ace replacement ")
                print(
                    f"player cards-----{player_cards}----{sum(player_cards)}")
            if sum(player_cards) > 21:
                print("bust player out  -----  computer wins ")
                break
            else:
                deasion = (input("hit or stand ")).strip(" ")
        else:
            if deasion == "stand":
                print(computer(computer_cards, player_cards))

        if input("do you want to continue playing press y or n ") != 'y':
            endloop = True
    else:
        print(f"{player_cards}----player has a black jack ,player wins ")
