##############################################################################
#project ceaser ciper program 
#################################################################################
# synatx of the function
# def my_func:
	#code of block
# my_fun()
###############################################
# def func():
# 	print("hello ",name)
# 	print("how it is going ")
# func()
######################################
# def func(name):
# 	print(f"hello {name}")
# func("angela")
#####################################
# name=angela name is the parameter aand angela is the argument
#####################################
# def greet_with(name,place):
# 	print(f"hello iam {name}")
# 	print(f"iam from {place}")
# greet_with("rohit","mumbai")#positional argument
######################################
# def my_function(a,b,c):
# 	print(a)
# 	print(b)
# 	print(c)
# my_function(a=1,c=9,b=8)#keyword arguments
#######################################
#paint calculator
########################################
# import  math
# height=int(input("enter the height"))
# width=int(input("enter the width"))
# area=height*width
# def paintcalc(area,area_per_can):
# 	number=area/area_per_can
# 	return number
# print(math.ceil(paintcalc(area,5)))
########################################
# interactive coding exercise  prime number checker
#########################################
# def prime_checker(number):
# 	if number %1==0:
# 		i=2
# 		while 2<=i<number:
# 			if number%i==0:
# 				s=True
# 				return s

# 			i+=1
# number=int(input("enter the number "))
# if prime_checker(number):
# 	print("composite")
# else:
# 	print("prime")	
#######################################33
# caesar cipher
####################################3###
from logo import  logo
print(logo)
run=1
while(run==1):
	alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',]
	direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
	text = input("Type your message:\n").lower()
	shift = int(input("Type the shift number:\n"))	
	if shift>len(alphabet)+1:
		shift=shift%(len(alphabet)+1)
	def encrypt(a,newlis):
		s=""
		for letter in a:
			if letter in alphabet:
				index=alphabet.index(letter)
				s+=newlis[index]
			else:
				s+=letter
		return s
	spaces=[i for i,value in enumerate(text) if value==" " ]
	if spaces:
		word_list=	text.split(" ")
	else:
		word_list=[text]
	if direction=="encode":
		
		enlis=alphabet[shift:]+alphabet[0:shift]
		for i in  word_list:
			print(encrypt(i,enlis),end=" ")
	elif direction=="decode":
		
		shift=(-1)*shift
		
		enlis=alphabet[shift:]+alphabet[0:shift]
		for i in  word_list:
			print(encrypt(i,enlis),end=" ")
	print("\n")
	run=int(input("do you want to continue if yes press 1 if no press 0"))
	print(run)


		










