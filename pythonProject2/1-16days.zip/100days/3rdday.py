##############################################
# if condition:
#   do this
# else :
#   do this
#############################################
# water_level=50
# if water_level>80:
#   print("drain the water")
# else:
#   print("continue filling ")
#############################################
# ticket for roller coster
# print("welcome to the roller coaster")
# height=int(input("enter the height"))
# bill=0
# if height>=120:
#   age=int(input("enter the age"))
#   if age<18:
#     bill=50
#     print(f"you pay {bill}ruppes")
#   elif age<25:
#     bill=80
#     print(f"you pay{bill}ruppes")
#   elif  age>=45 and age<=55:          #or 45<=age<55:
#     print("have a free ride ")
#   else :
#     bill=100
#     print(f"you pay {bill} ruppes")
#   photo=input("do you want to take a pic ?")
#   if photo == 'Y'or photo=='y':
#     print("totalbill",bill+3)
#   else:  
#     print("total bill",bill)
# else:
#   print("sorry,you have to grow taller before you ride")
########################################################################
num=float(input("which number do you what to check"))
if num>0:
	if num%2==0:             #debuging from day 13 num%2=0 is the relational error invalid syntax 
		print("number is even ")
	elif num%2==1:
		print("number is odd")
	else :
		print("invalid ")
else:
	print("number is negative ")
  #########################################################
# interactive coding exercise 
# year=input("enter the number ")  type is string which is invalid #13thday debuging exercise
year=int(input("enter the year"))
def isleap():
	if year%4==0:
		if year%100==0:
			if year%400==0:
				return True
			else:
				return False
	
		else:
			return True
	else:
		return False
		#interactive coding exercise  ---day 10 days in a month
def days_in_month(year,month):
	month_days=[31,28,31,30,31,30,31,31,30,31,30,31]
	days = month_days[month-1]
	if isleap() and days==28:
		days+=1
	return days
print(days_in_month(year,2))
#################################################################################################
#pizza order program 
# print("welcome to the pizza hut")
# size=input("enter the size  s for small and m for medium and l for large")
# add_pepper=input("do you want pepper y or n")
# extra_cheese=input("do you want extra cheese y or no")
# bill=0
# if size=='l':
#   bill=25
#   if add_pepper=='y':
#     bill+=3
#   if extra_cheese=='y':
#     bill+=1
# elif size=='m':
#   bill=20
#   if add_pepper=='y':
#     bill+=3
#   if extra_cheese=='y':
#     bill+=1
# elif size=='s':
#   bill=15
#   if add_pepper=='y':
#     bill+=2
#   if extra_cheese=='y':
#     bill+=1
# else:
#   print("invalid size")
# if bill!=0:
#   print(f"your final bill is {bill}")
############################################################################################
# if  condition1&condition2&condtion3:
#   do this 
# else:
#   do this                                                    logical operator
###########################################################################################
###interactive coding exercise 
# print("welcome to the love calculator")
# name1=input("enter the first name ")
# name2=input("enter the second name ")
 #tens place
# x=0 
# for i in ['t','r','u','e']: 
#   x+=((name1+name2).lower()).count(i)
# y=0
# for i in ['l','o','v','e']:
#   y+= ((name1+name2).lower()).count(i)
# z=10*x+y
# if z <90 or z<10:
#   print(f"your score {z},always together")
# elif 40<z<=50:
#   print(f"your score is {z},yor are alright together")
# elif  60<=z<70:
#   print(f"still come closer,you score is {z}")
# else:
#   print(f"your score{z}")
#############################################################################################
# print('''
# *******************************************************************************
#           |                   |                  |                     |
#  _________|________________.=""_;=.______________|_____________________|_______
# |                   |  ,-"_,=""     `"=.|                  |
# |___________________|__"=._o`"-._        `"=.______________|___________________
#           |                `"=._o`"=._      _`"=._                     |
#  _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
# |                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
# |___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
#           |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
#  _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
# |                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
# |___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
# ____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
# /______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
# ____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
# /______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
# ____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
# /______/______/______/______/______/______/______/______/______/______/_____ /
# *******************************************************************************
# ''')
# print("Welcome to Treasure Island.")
# print("Your mission is to find the treasure.") 
# dir=input("turn left or right ")
# dir=dir.strip()
# reach=0
# if dir.lower()=="left":
#   mode=input("do you like u swim or wait for the boat ")
#   ###assume there is not many  boat in left direction
#   ###water is easier to swim
#   if mode.lower()=="swim":
#     print("you choosen the best case because the water level is not that much dept waiting for the boat is waste of time ")
#     reach=1
#   else:
#     print("not a best case,after many hours boat arrived ")
#     n=int(input("if you are in boat how many people in the boat if not enter 0"))
#     if n>=2:
#       print("GAME OVER!!!")
#     else:
#       reach=1
# if dir.lower()=="right":
#   mode=input("do you like to go in boat or by swim  enter (boat or swim)")
#   ##assume dept of the water is larger in that direction so 
#   if mode.lower()=="boat":
#     print("you have choosan the best case because water level is so high,and swim is not the best idea ")
#     reach=1
#   else:
#     print("dept of the water you cannot able to swim finally  u are no more  ")
#     print("GAME OVER")
# lis=['green','blue','red']
# import random 
# x = random.randint(0,7)
# x=x%3

# if reach==1:
#   door=input("enter the color of the door to find the treasure")
#   if lis[x]==door:
#     print('''//////////////////////////////////////////////////////
#                money money money mangatha da !!! tresure is yours''')
#   elif lis[x]==door:
#     print("guards will catch you ,gameover ,guards will punish harshly")
#   else:
#     print("trap room if u go inside u never come back again  game over ")