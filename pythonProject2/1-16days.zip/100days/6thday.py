# #functions            #built in function  
# print("hello")
# num=len("print(hello)")
# print(num)

##########################self defining filter
# def my_function():
#   print("hello")
#   print("bye ")

# my_function()
##########################################
#defining the function syntax 
#def my_func();
  #do this 
  #then do this 
  #finally do this 
#func()

#############################################
# Reeborg's world.com
######################################
# turn_left()
# move()
# def rotate():
#     turn_left()
#     turn_left()
# def turn_right():
#     rotate()
#     turn_left()
# turn_right()
# move()
# turn_right()
# move()
# turn_right()
# move()
###########################################################
#hurdle problem
#####################
# def turn_right():
#     turn_left()
#     turn_left()
#     turn_left()
# def arrow6():   
#     move()
#     turn_left()
#     move()
#     turn_right()
#     move()
#     turn_right()
#     move()

#     from library import arrow6
# for i in range(6):
#     arrow6()
#     turn_left()
#################################################################################
#indentation###################################################################
# def func()
#   print(rrr)
# print(rrr)
################################################################################
#while loop ##loop which continue going when the particular condition is true 
################################################################################
# for items in list:
    #do something 
# for num in range(n):
    #do something
# working of for loop 

# while something is true:
    #do something 

#########################################
#   from library import arrow6
# hurdles=6
# while hurdles>0:
#     arrow6()
#     turn_left()
#     hurdles-=1  
#####################################
# while not(at_goal()):
    # arrow6()
    # turn_left()
#######    ############################
# hurdle challenge
#  def turn_right():
#     turn_left()
#     turn_left()
#     turn_left()
# def jump():
#     turn_left()
#     while (wall_on_right()):
#         move()
#     turn_right()
#     move()
#     turn_right()
     
 
#     while not(wall_in_front()):
#         move()
#     turn_left()
# while not(at_goal()):
#     if wall_in_front():
#         jump()
#     else:
#         move()
    ###########################################################
    #final project escaping the maze 
    ##################################################################################
#     def turn_right():
#     turn_left()
#     turn_left()
#     turn_left()
# while not(at_goal()):
#     if right_is_clear():
#         turn_right()
#     if front_is_clear():
#         move()
#     else:
        
#         turn_left()
######################################################################################
###########excaping the maze debuged program 
##########################################################################
# def turn_right():
#     turn_left()
#     turn_left()
#     turn_left()

# while front_is_clear():
#     move()
# turn_left()    
# while not(at_goal()):
#     if right_is_clear():
#         turn_right()
#         move()
#     elif front_is_clear():
#         move()
#     else:
#         turn_left()
###################################