#day 2 of the 100 day of code
#project : tip calculator

# print(len("sandy"))

#datatype
#string #"hello"
#  "hello"[0]
# 'h'
#  "123"
# '123'
#  "123"+"456"
# '123456'
#  #interger
#  print(123+345)
# 468
#  print(123_5_6+5_5)
# 12411
#  #float
#  pi=3.14159
#  #pi is the float
#  #bolean
#  True
# True
#  False==0
# True
#  False==1
# False
#  True==1
# True
#  True==0
# False# 

#Quiz time
################
###################################################################
# num_char=len(input("enter the name"))
# print(type(num_char))
# #we cannot able to add int and str
# num_char=str(num_char)
# print("your name has "+num_char+"characters")

# a=str(123)
# print(type(a))
# print(70+float("100"))
# print(str(70)+str(100))

# #ouputs
# enter the namesan
# <class 'int'>
# your name has 3characters
# <class 'str'>
# 170.0
# 70100

###############################################################################################
#coding excersize

#sum of digits

# num=int(input("enter the number"))
# s=0
# for i in str(num):
#   s+=int(i)
# print(s)

#output
# ~/100daysofpython/100days$ python 2ndday.py
# enter the number123
# 6
# ~/100daysofpython/100days$ python 2ndday.py
# enter the number316863864862872473647
# 109
# ~/100daysofpython/100days$ python 2ndday.py
# enter the number55555
# 25
# ~/100daysofpython/100days$ python 2ndday.py
# enter the number1010101010
# 5
# ~/100daysofpython/100days$ python 2ndday.py
# enter the number749871489273725239792747294937729757972589785259874739
# 318
#############################################################################################
#operator
#  333+5
# 338
#  7-4
# 3
#  3*2
# 6
#  6/3
# 2.0
#  2**3
# 8

#pemdaslr (),**,*,/,+,-
# 3*3+3/3-3
# 7.0
#  3*(3+3)/3-3
# 3.0

#interactive coding exercise
# BMI calculator

# height=float(input("enter the height in m "))
# weight=float(input("enter the weight in kg"))
# bmi=weight/height**2
# if bmi < 18.5:
#   print("underweight")
# elif 18.5<=bmi<25:
#   print("normal weight")
# elif 25<=bmi<30:
#   print("over weight")
# elif bmi>=30:
#   print("obese")

#######################################################################################
#  8/3
# 2.6666666666666665
#  int(8/3)
# 2
#  round(8/3)
# 3
#  round((8/3),2)
# 2.67
#  8//3
# 2
################################################3
#  result=4
#  result/=2
#  result
# 2.0
#  score=0
#  score+=1
#  score
# 1

###########################################################3
#fstrings
#  f"my{score}and my {result}is mu resul"
# 'my1and my 2.0is mu resul'

#############################################################################
# interactive exercise
# year = int(input("enter the year"))
# year_remain = 90 - year
# month_remain = year_remain * 12
# week_remain = year_remain * 52
# days_remain = year_remain * 365

# print(
#     f"to have {year_remain}and{month_remain}and{week_remain}and{days_remain}")
#############################################################
print("Welcome to the tip calculator ")
total_bill = float(input("what was a total bill?"))
tip = int(input("what was a percentage tip you like to give ?"))
tip_amount = (tip / 100) * total_bill
netbill = total_bill + tip_amount
split = int(input("how many people to split the bill?"))
print("each person should pay ", round(netbill / split, 2))
