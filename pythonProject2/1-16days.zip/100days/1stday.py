
#end of the module  project :band name generator 



# print("hello world")    #double cote is the string 
# print("Day 1 - Python Print Function\nThe function is declared like this:\nprint('what to print')")
# print("hello"+ " "+"world" ) #string concondination

################input( funciton)
# print("hello "+input("enter the name of the person"))  #--to comment 
#length of the string 

# print(len(input("enter the string ")))

#variable
# name =input("enter the number ")
# print(name)

#switch the values
# a=int(input("enter the number"))
# b=int(input("enter the value of b "))
# #by using third variable 
# temp=a
# a=b
# b=temp
# print(a)
# print(b)

# #by using bitwise operator of xor 
# a=a^b
# b=a^b
# a=a^b
# print(a)
# print(b)

##withour using third variable
# a=a+b
# b=a-b
# a=a-b
# print(a)
# print(b)

#call by reference

# def reference(a,b):
#   a,b=b,a
#   return a,b
# for i in 0,1:
#   print(reference(a,b)[i])

#1st project of the course 
#band name generator 

from random import randint
lis=[input("enter the place you are from "),input("pet u like "),input("enter the number of members in the band "),input("any king queen or jack which one do u like "),input("enter the animal dangers animal")]
for _ in range(12):
  s=""
  for _ in range(2):
    s+=lis[randint(0,4)]
  print(s)

#quiz  one
# def foo(a=3,b=4,c=6):
#   print(a,b,c)
# foo()                               #output 3,4,6

# def foo(a,*arg,**kw):
#   print(a,arg,kw)
# foo(4,7,3,0,x=10,y=64)          #output 4 (7, 3, 0) {'x': 10, 'y': 64}

# num=[1,1,2,3,5,8,13,21]
# result =[n+3 for n in num if n%2==0]
# print(result)

#quiz 2
###########################################completion of the first day########################




