# import random
# # random.seed(3) is like fixing the particular value 
# random_interger=random.randint(1,10)
# print(random_interger)
# random_fraction=random.random()
# print(random_fraction)

# #floating point number between 1 to 10
# print(random_interger*random_fraction)



# ##################################################################
# #moodified love calculator project 
# love_score=random.randint(1,100)
# print(f"love score is {love_score}")
#######################################################################
# import random
# import time 
# print(" commantator(danny morrison )  vanakaaam chennayyyyy   ")
# time.sleep(10)
# print("todayyyy the bigggg game cskkk vs rcb  ,match refreeeeeee illigoooo ")
# print("virat u have coin ")
# print("virat spins")
# print("tail is the call ")
# ran=random.randint(0,2)
# print(ran)
# if ran:
#   print("official seeing the toss.....  ")
#   time.sleep(10)

#   print("heads it is ")
#   print("am i won the toss its unbeliveable ")
#   time.sleep(1)
#   print("virat what u decided to")
#   time.sleep(1)
#   print("pitch is looling good so we bat first ")
#   print("after the talk ,rcb won the toss boom bat first ")
# else:
#   print("official seeing the toss.....  ")
#   time.sleep(10)

#   print("tails it is ")
#   time.sleep(1)
#   print("dhonoi what u decided to")
#   time.sleep(1)
#   print("pitch is looling good so we bowl first ")
#   print("csk  won the toss  little bit swing ")
####################################################################################
#python lists
#fruits=[item1,item2]
######################################################################################
# states_of_india=['jammu',"madya pradesh","maharastra","tamil nadu"]
# print(states_of_india[1])
# print(states_of_india[-2])
# states_of_india[2]="mumbai"
# print(states_of_india[-2])
################################################################################
#interactive coding exercise 
#banker roulette
########################################################################
# all_name=input("name of the owner of the card")    #names, names, names, 
# x=all_name.split(", ")
# print(x)
# import random
# i=random.randint(0,len(x)-1)
# print(f"{x[i]} has to pay the bill " )
############################################################
#mofied program 
# choice=random.choice(x)
# print(f"{choice} have to pay the bill")
#####################################################################################
# index errors and working with nested lists
# vegetable=["spinach","kale","tomatoes","celery","potatos"]
# fruit=["apple","mango","cherries"]
# sirty_dozen=[vegetable,fruit]
###############################################################################
#interactive coding excersie ###########################
# tresure map
#############################################################################
# map=[[1,1,1],[1,1,1],[1,1,1]]
# for i in map:
  # print(i)
# import random 
# i=3
# j=1
# map[i-1][j-1]='x'
# for i in map:
#   print(i)
####alternative working with string #################
# row_column=input("enter the row and column")
# row=int(row_column[0])-1
# column=int(row_column[1])-1
# map[row][column]='x'
# for i in map:
  # print(i)
######################################################################################
#########################################################################################
# lis=[0,1,2]
# import random
# computer=random.choice(lis)
# x=int(input("you choose"))
# if x<3 and x>-1:
  
#   def reduce(x):
#     if x==1:
#       print("pic of papper")
#     if x==0:
#       print("pic of rock")
#     if x==2:
#       print("scisoor")
#   reduce(x)
#   reduce(computer)
#   print(x)
#   print(computer)

#   if computer==0 and x==2:
#     print("computer wins")
#   elif x==0 and computer==2:
#     print("user wins")
#   elif x>computer and x<3 and computer<3:
#     print("user wins ")
#   elif computer>x and x<3 and computer<3:
#     print("computer wins ")
#   elif computer == x:
#     print("match is drawn ")

# else:
#   print("invvalid input")


