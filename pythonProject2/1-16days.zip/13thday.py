#debugging the process of removing the bug##
#############################################################
############DEBUGGING#####################
################################################################
# # Describe Problem
################################################################
# def my_function():
#   for i in range(1, 20):  #------ i index is from 1 to 19 i never reaches 20  ------ this was a bug  replace range(1,21)
#     if i == 20:
#       print("You got it")
# my_function()
# #debugged
################################################################
# # Reproduce the Bug
################################################################
# from random import randint
# dice_imgs = ["❶", "❷", "❸", "❹", "❺", "❻"]
# dice_num = randint(1,6)  #randint include both the end point 1,6 where in the list only 0 to 5 index  when dice_num  6 error occurs  to debug replace randint(0,len(list)-1)
# print(dice_imgs[dice_num])
##################################################################

# # Play Computer
##################################################################
# year = int(input("What's your year of birth?"))
# if year > 1980 and year < 1994: #----whole set of year 1980 and 1994 is missing in the sequence please include it to get a whole set of year  by  simply equal in the conditions
#   print("You are a millenial.")
# elif year > 1994:
#   print("You are a Gen Z.")
#############################################################3
# # Fix the Errors
##############################################################
# # age = input("How old are you?")  #---datatype 
# age=int(input("how old are you?")) #---debuged by using the int 
# if age > 18:
# # print("You can drive at age {age}.") #---indentation error
# 	print("You can drive at age {age}.") #debuged indentation
########################################################### 
# #Print is Your Friend
##########################################################3

# pages = 0
# word_per_page = 0
# pages = int(input("Number of pages: "))
# # word_per_page == int(input("Number of words per page: "))
# word_per_page = int(input("Number of words per page: ")) #debuged using print 
# total_words = pages * word_per_page
# print(word_per_page) #to check
# print(pages)           #to check
# print(total_words)
###############################################################
# #Use a Debugger  --  python tutor
##########################################################3
# def mutate(a_list):
# 	b_list = []
# 	for item in a_list:
# 		new_item = item * 2
# 	#   b_list.append(new_item)  by using debugger i found the intent error
# 		b_list.append(new_item)  #debugged error
# 	print(b_list)

# mutate([1,2,3,5,8,13])
############################################################
# odd or even interactive exercise bug is fixed  go to day 3 to fix the problem 

#leap year program type error 3rd day