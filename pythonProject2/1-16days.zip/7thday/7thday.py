#############################################################################
###hangman projct ####
##############################################################################
#step -1
from lives import *
from words import *
#import the random to randomly choose the element in the list 
import random
choosen_word=random.choice(word_list)

spaces=['_']*len(choosen_word)
end_of_game=False
lives=6
inputed=''
print(logo)
print(spaces)
x=[]
# while("_"in spaces):
	# spaces=["_" for i in choosen_word]
from os import system 
while (not(end_of_game))and (lives!=0):

	inputed=input("enter the ")
	while (inputed in x ):
		print(f"{inputed}already there try another letter")
		inputed=input("try another letter")
		# inputed=input("enter the letter").lower()
		
	x+=[inputed]	
	
	system("clear")
	for letter in range(len(choosen_word)):
		if choosen_word[letter]==inputed:
			spaces[letter]=inputed
			print('''''''''''''''''''''''',"type is correnct")
	if (inputed not in choosen_word):
		lives-=1
		print(stages[lives])
	else:
		print(stages[lives])
	for i in spaces:
		print(i,end="")
	
# else:
	# print('they"ve won')	
		# 1# else:
		# 1# 	print("nomatch")
	if ("_" not in spaces):
		end_of_game=True
	
else:
	if lives==0:
		print("\nword is ",choosen_word)
		print("out of lives")
	else:
		print(choosen_word)
		print("you have won")


