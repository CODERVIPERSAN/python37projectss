################higer or lower projec#############################

from higerlogo import logo
from data1 import data 

from random import choices
endgame=False
SCORE=0




def a_region(data_dict):
	for dat in data_dict :
		if dat=="follower_count":
			return data_dict[dat]



def comparion(user,A,B):
	if user=='A':
		if a_region(A)>a_region(B):
			return False
		else:
			return True 
	elif user=='B':
		if a_region(B)>a_region(A):

			return False
		else :
			return True 

while not(endgame):
	from higerlogo import vs
	comparison_list1=choices(data)
	comparion_list2=choices(data)
	
	if SCORE==0:
		A=comparison_list1[0]
		B=comparion_list2[0]

	elif SCORE>0:
		if user=='B':
			A=B
			B=comparion_list2[0]
		elif user=='A':
			B=comparion_list2[0]
			

	from data1 import format
	from os import system 
	print(logo)
	print(format(A))
	print(vs)
	print(format(B))
	user=(input("who has a more followers a or b").upper()).strip()
	system("clear")
	


	if not(comparion(user,A,B)):
		SCORE+=1
		print("the current score ",SCORE)
	else:
		print(logo)
		print("gameover",SCORE)
	
	endgame=comparion(user,A,B)
	
