#####################scope############################################
# enemies=1
# def increase_enemy():
# 	enemies=2
# 	print(enemies)
# increase_enemy()
# print(enemies)
###################################################################
# a=10
#dynamic scoping 
def ai():
	a=20
	print("ai",a)
	def h():
		print(a)


#python is the static scoping programming language 

###################################################################
#global scope (for all )
#local scope  (within the indent)
################################################################
#c++ java has a block scope 
#but python doesnt have a block scope
####################################################################

if 3>2:
	a=45  #still it is a global scope 
# print(a)

###########################
#modifing the global scope 1
##############################
gamelevel=3
new_enemy="kiya"   #------1
def create_enemy():                          #only function can say whether local scope or global scope 
	enemies=["vampire","gost","alien"]
	if gamelevel<5:
		global new_enemy
		new_enemy=enemies[0]
                 							#------no block scope 
create_enemy()
print(new_enemy)
########################################################################

PI=3.14
def calc():
	r=int(input())
	return PI*r**2
# URL="tinyurl.net"
# print(calc())

#####################################################################doubt solving

# a=10
# def a1():
# 	a=20
# 	def a2():
# 		a=30
# 	a2()
# a1()
# print(a)

################################################################
####number guessing game ###############################
print("WELCOME TO THE NUMBER GUESSING GAME !")
print("think a number in a range of 1 to 100")
from random import randint 
crt_guess=randint(1,100)

def comparison(guess):
	"""compare the user_ guess and the  crt_guess and return the information about the guess"""
	if guess==crt_guess:
		print("you achieved the guess ,congrats")
	elif abs(guess-crt_guess)==1:
		print("near you almost there ,did you have ")
		print("did you have life ,if you have, u going to crack this ")
	elif 0<(guess - crt_guess)<=5:
		print("slight higher ")
	elif 0<(crt_guess-guess)<=5:
		print("slight lower")
	elif guess>crt_guess:
		print("guess is too higher")
	elif guess<crt_guess:
		print("guess is too low ")
#difficulty
difficulty=input("choose the difficulty .Type easy , medium , hard").strip()
if difficulty=="easy":
	n=9
elif difficulty=="medium":
	n=6
elif difficulty=="hard":
	n=4
#for repeating upto life
for life in range(n):
	print(f"you have{n-life} attempts remaining for this game")
	guess=int(input("make a guess"))
	comparison(guess)
	if guess==crt_guess:
		win=True
		break
	win=False
	#decision
if not(win):
	print(f"out of guesses ,you loss and the crt guess is {crt_guess}")
else:
	print("you won ")
################################################################

##########completed only by me ################################


 

