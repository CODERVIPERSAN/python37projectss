#functions with output 
# #USE OF TITLE FUNCTIONS
def format_name(string):
	"""get the set of string and capitalize the first letter in each word"""     #doc string used for documentation
	if string=="":
		return "you not enter anything"
	s=string.title()
	return s

# string=input("enter the information")
# print(format_name(input()))

#WORKING OF THE TITLE CASE 
#USING REGULAR EXPRESSION
# import re 
# def tit(s):
# 	return re.sub(r"[A-Za-z]+('[A-Za-z]+)?",lambda a: a.group(0).capitalize(),s)
# print(tit("Sandy SaAs ssss AAAA"))

#by using regular expression 
#######################################################################
#interactive coding 
# day 3  leap year program modified please refer day 3
#completed 
####################################################################
#docstrings """ written inside function creats documentation"""
import os 
enloop=False
n=0 #to infer iteration
while(enloop==False):
	def add(n1,n2):
		"""just add the two numbers"""
		return n1+n2
	def multiplication(n1,n2):
		"""just multiplication of two numbers"""
		return n1*n2
	def division(n1,n2):
		"""divide two number """
		return multiplication(n1,(1/n2))

	def subtract(n1,n2):
		"""just subtract the two number"""
		return n1-n2
	calc={}
	calc['+']=add
	calc['-']=subtract
	calc['*']=multiplication
	calc['/']=division

	if n==0:
		from logo1 import logo
		print(logo)
		n1=int(input("first number "))
		n2=int (input("enter the second number "))
	elif n!=0:
		n1=answer
		n2=int(input("enter the second "))
	user=input("enter the symbol")
	answer=0
	for op in calc:
		if user==op:
			answer=calc[op](n1,n2)
			break
	
	print(f"{n1}{user}{n2}which is equal to {answer}")
	info=input("can we off the calculator")
	if info=='yes':
		enloop=True
	elif info=='no':
		how=input("new calculation????")
		if how=='yes':
			n=0
			os.system('clear')
		else:
			n+=1
		enloop=False
			
#project done
#next day
#--------------------------------------------------------------------# 
#capstone project 



